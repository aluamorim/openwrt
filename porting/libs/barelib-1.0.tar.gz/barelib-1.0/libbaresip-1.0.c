 /**************** * Helloworld.c * The most simplistic C program ever written. * An epileptic monkey on crack could write this code. *****************/ 
 #include <stdio.h> 
int main(void) { 
	printf("Hell! O' world, why won't my code compile?\n\n"); 
	return 0; 
}
